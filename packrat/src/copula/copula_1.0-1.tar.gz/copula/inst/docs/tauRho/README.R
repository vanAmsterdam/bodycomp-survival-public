## generate the sysdata.rda file used in the copula package.

source("trpsrho.R")
source("trpstau.R")

source("evtrps.R")

source("getSysdataImage.R")
