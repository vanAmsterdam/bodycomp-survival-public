[![](http://cranlogs.r-pkg.org/badges/grand-total/smcfcs)](https://cran.r-project.org/package=smcfcs)

smcfcs is an R package implementing Substantive Model Compatibly Fully Conditional Specification Multiple Imputation. Examples and further details are given in the package documentation and vignette.

To install the latest GitHub development version, run:

```r
install.packages("devtools")

devtools::install_github("jwb133/smcfcs")
```
