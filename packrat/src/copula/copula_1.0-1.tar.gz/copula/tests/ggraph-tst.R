require(copula)
doX <- FALSE # no "doExtras" -- be fast

demo(gof_graph)
